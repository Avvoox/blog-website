// scroll up
window.onscroll = function() {
    scrollFunction();
};

function scrollFunction() {
    var backToTopBtn = document.getElementById("backtotop");

    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        backToTopBtn.style.opacity = "1";
    } else {
        backToTopBtn.style.opacity = "0";
    }
}

// Smooth scroll to top when button is clicked
document.getElementById("backtotop").addEventListener("click", function() {
    scrollToTop(1000); // Scroll to top in 1000 milliseconds (1 second)
});

function scrollToTop(duration) {
    var start = window.pageYOffset;
    var startTime = performance.now();

    function scroll() {
        var currentTime = performance.now();
        var timeElapsed = currentTime - startTime;
        window.scrollTo(0, easeInout(timeElapsed, start, -start, duration));

        if (timeElapsed < duration) {
            requestAnimationFrame(scroll);
        } else {
            window.scrollTo(0, 0);
        }
    }

    function easeInout(t, b, c, d) {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }

    requestAnimationFrame(scroll);
}

// Initially hide the button when the page loads
document.getElementById("backtotop").style.opacity = "0";