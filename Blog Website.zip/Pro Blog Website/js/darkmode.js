// Dark Mode toggle button js

let toggledark = document.querySelector('#toggledark');
let body = document.body;

// Check if there is a stored dark mode preference in localStorage
const isDarkMode = localStorage.getItem('darkMode') === 'true';

// Set the initial state based on the stored preference
if (isDarkMode) {
    body.classList.add('dark');
    toggledark.checked = true;
}

toggledark.addEventListener('change', () => {
    if (toggledark.checked) {
        body.classList.add('dark');
        // Store dark mode preference in localStorage
        localStorage.setItem('darkMode', 'true');
    } else {
        body.classList.remove('dark');
        // Remove dark mode preference from localStoragef
        localStorage.setItem('darkMode', 'false');
    }
});