// searchbar click To show input

let search = document.querySelector('.searchbar');
let searchicon = document.querySelector('#searchicon')
let searchinput = document.querySelector('#searchinput');
let removesearch = document.querySelector('#removesearch')

searchinput.style.display = 'none';
removesearch.style.display = 'none';

search.addEventListener('click', () => {
    if (searchinput.style.display === "none") {
        searchinput.style.display = 'block';
        removesearch.style.display = 'block';
        searchicon.style.display = 'none';
    } else {
        searchinput.style.display = 'none';
        removesearch.style.display = 'none';
        searchicon.style.display = 'block';
    }
});





// JSON data representing the content ---------->

const postData = {
    "gridposts": [

        {
            "id": "1",
            "image": "img/leptop post.jpg",
            "label": "laptop",
            "title": "11 of best laptops evaluated based on budget",
            "author": "Coder Mak",
            "date": "by CODER October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "1",
            "image": "img/watch post.jpg",
            "label": "Apple",
            "title": "apple watch series 5 is the best one yet by consumer",
            "date": "October 02, 2023",
            "time": "2023-10-01",
            "href": "https://www.google.com"
        },
        {
            "id": "2",
            "image": "img/leptop post.jpg",
            "label": "laptop",
            "title": "11 of Best Laptops Evaluated Based on Budget",
            "date": "October 18, 2023",
            "time": "2023-10-01",
            "href": "https://www.facebook.com"
        },
        {
            "id": "3",
            "image": "img/post4.jpg",
            "label": "Apple",
            "title": "18 Practices for building responsive web applications",
            "date": "October 02, 2023",
            "time": "2023-10-01",
            "href": "https://www.instagram.com"
        },
        {
            "id": "4",
            "image": "img/post5.jpg",
            "label": "healthy",
            "title": "how to get COVID-19 related alerts on your phone",
            "time": "2023-10-01",
            "href": "https://www.instagram.com"
        },
        {
            "id": "5",
            "image": "img/post6.jpg",
            "label": "healthy",
            "title": "How We Know Disinfectants Should Kill the Covid-19",
            "date": "October 02, 2023",
            "href": "https://www.instagram.com"
        },
        {
            "id": "6",
            "image": "img/post7.jpg",
            "label": "healthy",
            "title": "Car sefety tips to protect you and your family",
            "date": "October 02, 2023",
            "href": "https://www.instagram.com"
        },
        {
            "id": "7",
            "image": "img/post8.jpg",
            "label": "healthy",
            "title": "know how to protect your health when going out",
            "date": "October 02, 2023",
            "href": "https://www.instagram.com"
        },
        {
            "id": "8",
            "image": "img/post9.jpg",
            "label": "healthy",
            "title": "tracking pubic and private response to the COVIED-19",
            "date": "October 02, 2023",
            "href": "https://www.instagram.com"
        },
        {
            "id": "9",
            "image": "img/post12.jpg",
            "label": "consoles",
            "title": "The best xbox 360 co-op offline split-screen games",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "10",
            "image": "img/post13.jpg",
            "label": "consoles",
            "title": "great local multiplayer games to play on PS5",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/post14.jpg",
            "label": "deals",
            "title": "how to equip your studio like the top tech",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/post15.jpg",
            "label": "deals",
            "title": "the best wired and wireless gaming headset",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/post16.jpg",
            "label": "deals",
            "title": "lessons learned selling cheap electronics",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/post17.jpg",
            "label": "consoles",
            "title": "13 playstation 5 tips to get the most out",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/post18.jpg",
            "label": "gadgets",
            "title": "6 wealth building alternatives",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/gadgets1.jpg",
            "label": "gadgets",
            "title": "Start a Digital Marketing Website for your Service",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/gadgets2.jpg",
            "label": "gadgets",
            "title": "Part-time Trading on Forex as an Alternative Income",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/gadgets3.jpg",
            "label": "gadgets",
            "title": "Catch the Best iPhone X Deals Plus Your Favorite gadgets",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/leptop post.jpg",
            "label": "laptop",
            "title": "11 of best laptops evaluated based on budget",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/post19.jpg",
            "label": "laptop",
            "title": "Apple Watch Series 5 is the Best One Yet By Consumer",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/post20.jpg",
            "label": "laptop",
            "title": "Here's What People Think of iOS 13 New Dark Mode",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/post21.jpg",
            "label": "laptop",
            "title": "18 Practices for Building Responsive Web Applications",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/leptop post.jpg",
            "label": "laptop",
            "title": "11 of best laptops evaluated based on budget",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/travel1.jpg",
            "label": "travel",
            "title": "5 of best travel in budget",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/travel2.jpg",
            "label": "travel",
            "title": "11 of best travel in budget",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/travel3.jpg",
            "label": "travel",
            "title": "9 of best travel in budget",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
        {
            "id": "11",
            "image": "img/travel4.jpg",
            "label": "travel",
            "title": "45 of best travel in budget",
            "author": "Coder Mak",
            "date": "October 02, 2023",
            "href": "https://www.google.com"
        },
    ]
};



// Notification text change ------------>

let notileft = document.querySelector('#notileft');
let notiright = document.querySelector('#notiright');
let index = 0; // Initialize index variable

// Function to change the text inside the element
function changeText(newIndex) {
    var textElement = document.querySelector('.text_change');
    textElement.textContent = postData.gridposts[newIndex].title;
    index = newIndex;
}

// Call the changeText function every 4 seconds
setInterval(function () {
    changeText((index + 1) % postData.gridposts.length);
}, 4000); // 4000 milliseconds = 4 seconds

// Add click event listeners to notileft and notiright buttons
document.querySelector('#notileft').addEventListener('click', function () {
    var newIndex = (index - 1 + postData.gridposts.length) % postData.gridposts.length;
    changeText(newIndex);
});

document.querySelector('#notiright').addEventListener('click', function () {
    var newIndex = (index + 1) % postData.gridposts.length;
    changeText(newIndex);
});



const filteredhealthy = postData.gridposts.filter(post => post.label === 'healthy');

filteredhealthy.forEach(function (post, index) {
    let gridpost = document.getElementsByClassName('healthpost')[index];
    gridpost.href = post.href;
    gridpost.getElementsByTagName('img')[0].src = post.image;
    gridpost.getElementsByClassName('label')[0].textContent = post.label;
    gridpost.getElementsByTagName('h2')[0].textContent = post.title;
    gridpost.getElementsByTagName('p')[0].textContent = post.date;
    gridpost.getElementsByClassName('a').href = post.href;
});


// consoles filter data
const filterConsole = postData.gridposts.filter(post => post.label === 'consoles' || post.label === 'deals');

filterConsole.forEach(function (post, index) {
    let revpost = document.getElementsByClassName('revpost')[index];
    revpost.href = post.href;
    revpost.getElementsByTagName('img')[0].src = post.image;
    revpost.getElementsByClassName('label')[0].textContent = post.label;
    revpost.getElementsByTagName('h2')[0].textContent = post.title;
    revpost.getElementsByTagName('p')[0].textContent = post.date;
    revpost.getElementsByClassName('a').href = post.href;
});

// Gadgets filter data
const filterGadgets = postData.gridposts.filter(post => post.label === 'gadgets');

filterGadgets.forEach(function (post, index) {
    let gadpost = document.getElementsByClassName('gadpost')[index];
    gadpost.href = post.href;
    gadpost.getElementsByTagName('img')[0].src = post.image;
    gadpost.getElementsByClassName('label')[0].textContent = post.label;
    gadpost.getElementsByTagName('h2')[0].textContent = post.title;
    gadpost.getElementsByTagName('p')[0].textContent = post.date;
    gadpost.getElementsByClassName('a').href = post.href;
});


// laptop Posts
const filterlaptop = postData.gridposts.filter(post => post.label === 'laptop');

document.addEventListener('DOMContentLoaded', function () {
    filterlaptop.forEach(function (post, index) {
        let laptpost = document.getElementsByClassName('laptpost')[index];
        if (laptpost) {
            laptpost.getElementsByTagName('img')[0].src = post.image;
            laptpost.getElementsByClassName('label')[0].textContent = post.label;
            laptpost.getElementsByTagName('h2')[0].textContent = post.title;
            laptpost.getElementsByTagName('p')[0].textContent = post.date;
            laptpost.href = post.href;
        }
    });
});


// Top Post
const TopPost = postData.gridposts.sort((a, b) => new Date(b.time) - new Date(a.time));
document.addEventListener('DOMContentLoaded', function () {
    TopPost.forEach(function (post, index) {
        let laptpost = document.getElementsByClassName('toppost')[index];
        if (laptpost) {
            laptpost.getElementsByTagName('img')[0].src = post.image;
            laptpost.getElementsByClassName('label')[0].textContent = post.label;
            laptpost.getElementsByTagName('h2')[0].textContent = post.title;
            laptpost.getElementsByTagName('p')[0].textContent = post.date;
            laptpost.href = post.href;
        }
    });
});


// latest Posts
const latestPostCont = document.querySelector('.latestdata');

const latestPostData = () => {
    postData.gridposts.slice(0, 5).map((latestdata) => {
        const postElement = document.createElement('a');
        postElement.classList.add('gpost')
        postElement.classList.add('flex')
        postElement.classList.add('latepost')
        postElement.href = `${latestdata.href}`
        postElement.innerHTML = `
       <div class="latepostimg">
                                <img src="${latestdata.image}" alt="">
                                <span class="label">${latestdata.label}</span>
                            </div>
                            <div class="postinfo npostinfo">
                                <h2>${latestdata.title}</h2>
                                <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus inventore, beatae
                                    sequi temporibus soluta assumenda....</h5>
                                <p>${latestdata.date}</p>
                            </div>
       `
        latestPostCont.appendChild(postElement);
    })
}
latestPostData()



const PopularPost = postData.gridposts.sort((a, b) => new Date(b.time) - new Date(a.time));
document.addEventListener('DOMContentLoaded', function () {
    PopularPost.forEach(function (post, index) {
        let laptpost = document.getElementsByClassName('popular')[index];
        if (laptpost) {
            laptpost.getElementsByTagName('img')[0].src = post.image;
            laptpost.getElementsByClassName('label')[0].textContent = post.label;
            laptpost.getElementsByTagName('h2')[0].textContent = post.title;
            laptpost.getElementsByTagName('p')[0].textContent = post.date;
            laptpost.href = post.href;
        }
    });
});



// Travel Posts
const TravelFilter = postData.gridposts.filter(post => post.label === 'travel');

document.addEventListener('DOMContentLoaded', function () {
    TravelFilter.forEach(function (post, index) {
        let laptpost = document.getElementsByClassName('trapost')[index];
        if (laptpost) {
            laptpost.getElementsByTagName('img')[0].src = post.image;
            laptpost.getElementsByClassName('label')[0].textContent = post.label;
            laptpost.getElementsByTagName('h2')[0].textContent = post.title;
            laptpost.getElementsByTagName('p')[0].textContent = post.date;
            laptpost.href = post.href;
        }
    });
});


// footer latest Post
const footerLatestPosts = document.querySelector('.footerlatestposts');

const latestPostfooter = () => {
    postData.gridposts.slice(4, 7).map((latestdata) => {
        const postElementF = document.createElement('a');
        postElementF.classList.add('gpost')
        postElementF.classList.add('flex')
        postElementF.classList.add('npost')
        postElementF.classList.add('ppost')
        postElementF.href = `${latestdata.href}`
        postElementF.innerHTML = `
        <img src="${latestdata.image}" alt="${latestdata.title}">
        <div class="postinfo npostinfo ppostinfo">
            <span class="label"></span>
            <h2>${latestdata.title}</h2>
            <p>${latestdata.date}</p>
        </div>
       `
        footerLatestPosts.appendChild(postElementF);
    })
}
latestPostfooter();


// // footer Pupular Post
const footerLatestPosts2 = document.querySelector('.footerpopu');

const PopuPostfooter = () => {
    postData.gridposts.slice(6, 9).map((latestdata) => {
        const postElementF = document.createElement('a');
        postElementF.classList.add('gpost')
        postElementF.classList.add('flex')
        postElementF.classList.add('npost')
        postElementF.classList.add('ppost')
        postElementF.href = `${latestdata.href}`
        postElementF.innerHTML = `
        <img src="${latestdata.image}" alt="${latestdata.title}">
        <div class="postinfo npostinfo ppostinfo">
            <span class="label"></span>
            <h2>${latestdata.title}</h2>
            <p>${latestdata.date}</p>
        </div>
       `
        footerLatestPosts2.appendChild(postElementF);
    })
}
PopuPostfooter();